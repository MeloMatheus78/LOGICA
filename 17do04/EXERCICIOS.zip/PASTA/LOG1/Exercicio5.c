/*
5. Faça um algoritmo que leia 20 números e armazene em um vetor. Depois, some os 10
primeiros elementos deste vetor;
*/

#include <stdio.h>

int main() {
    int i;
    int numerosLidos[20];
    for ( i = 0; i < 20; i++)
    {
        printf("DIGITE O %d° NUMERO: ", i+1);
        scanf("%d", &numerosLidos[i]);
    }

    int soma = 0;

    for ( i = 0; i < 10; i++)
    {
        soma = soma + numerosLidos[i];    
    }

    printf("O VALOR DA SOMA EQUIVALE A: %d ", soma);
    
    return 0;
}