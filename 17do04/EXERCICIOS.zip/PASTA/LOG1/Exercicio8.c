#include <stdio.h>

int main() {
    int vetor[10];
    int i;
    int A, B, C;
    int contA = 0, contB = 0, contC = 0;

    for(i = 0; i < 10; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", &vetor[i]);
    }

  
    printf("\nDigite o valor de A: ");
    scanf("%d", &A);

    printf("Digite o valor de B: ");
    scanf("%d", &B);

    printf("Digite o valor de C: ");
    scanf("%d", &C);

    for(i = 0; i < 10; i++) {
        if(vetor[i] == A) {
            contA++;
        }
        if(vetor[i] == B) {
            contB++;
        }
        if(vetor[i] == C) {
            contC++;
        }
    }

    printf("\nO numero %d apareceu %d vezes.\n", A, contA);
    printf("O numero %d apareceu %d vezes.\n", B, contB);
    printf("O numero %d apareceu %d vezes.\n", C, contC);

    return 0;
}