/*
    4. Crie um algoritmo para ler 15 números inteiros e mostrar no final, os que forem maiores
ou igual a 10;
*/

#include <stdio.h>

int main() {
    int i;
    int numerosLidos[15];

    for ( i = 0; i < 15; i++)
    {
        printf("DIGITE O %d° NUMERO: ", (i+1));
        scanf("%d", &numerosLidos[i]);
    }
    
    printf("SOMENTE NUMEROS MAIORES OU IGUAIS A 10!\n");
    for (i = 0; i < 15; i++)
    {
        if (numerosLidos[i]>= 10)
        {
            printf("%d ", numerosLidos[i]);
        }
        
    }
    
    
}