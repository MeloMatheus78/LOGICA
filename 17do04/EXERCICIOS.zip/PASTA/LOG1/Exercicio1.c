#include <stdio.h>

int main() {
    //Ler dez elementos de uma matriz unidimensional do tipo inteiro e apresentar os valores lidos;

    int numerosLidos[10];
    int i;

    for ( i = 0; i < 10; i++)
    {
        printf("DIGITE O %d° NUMERO: ", (i+1));
        scanf("%d", &numerosLidos[i]);
        printf("\n");
    }

    printf("OS NUMEROS DIGITADOS FORAM: ");
    for ( i = 0; i < 10; i++)
    {
        printf("%d ", numerosLidos[i]);
    }
    
    
    return 0;
}