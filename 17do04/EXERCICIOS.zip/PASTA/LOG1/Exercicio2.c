/*
    Ler oito elementos inteiros em uma matriz unidimensional (A). Construir uma matriz B de
mesma dimensão com os elementos da matriz A multiplicados por 3. Após, apresente
os números da matriz B. Exemplo: o elemento B|0] deve ser implicado pelo elemento
A[0)*3, o elemento B[1] deve ser implicado pelo elemento A[1]*3 e assim por diante, até
a última posição:
*/
#include <stdio.h>

int main() {
    printf("MULTIPLICADORA DE ARRAYS\n");
    int i;
    int numerosLidos[8];

    for (i = 0; i < 8; i++) {
        printf("DIGITE O %d° NUMERO: ", (i+1));
        scanf("%d", &numerosLidos[i]);
    }

    int numerosMultiplicados[8];

    printf("VALORES MULTIPLICADOS: ");
    for (i=0; i<8; i++) {
        numerosMultiplicados[i] = numerosLidos[i] * 3;
        printf("%d ", numerosMultiplicados[i]);
    }
}