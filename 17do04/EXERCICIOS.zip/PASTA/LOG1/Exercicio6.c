/*
6. Faça um algoritmo para ler um vetor com 10 elementos e inverter a posição destes
elementos, de tal modo que o primeiro elemento venha a ser o último depois da
inversão;
*/

#include <stdio.h>

int main() {
    int i;
    int numerosOrdinaisSafados[10];

    for ( i = 0; i < 10; i++)
    {
        printf("DIGITE O %d° NUMERO: ", i+1);
        scanf("%d", &numerosOrdinaisSafados[i]);
    }
    printf("INVERTENDO A ORDEM :\n");
    for ( i = 9; i >= 0; i--)
    {
        printf("%d ", numerosOrdinaisSafados[i]);
    }
    
    

}