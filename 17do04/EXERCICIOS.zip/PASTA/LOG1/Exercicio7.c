/*
Faça um algoritmo que leia 30 valores do tipo inteiro e armazene-os em um vetor. A
seguir, o algoritmo deverá informar (1) todos os números pares que existem no vetor; (2)
o menor e o maior valor existente no vetor; (3) quantos dos valores do vetor são maiores
que a média desses valores:
*/
#include <stdio.h>

int main() {
    int vetor[30];
    int i;
    int soma = 0;
    float media;
    int menor, maior;
    int contador_acima_media = 0;

    for(i = 0; i < 30; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", &vetor[i]);
        soma += vetor[i];

        // Inicializa menor e maior
        if(i == 0) {
            menor = vetor[i];
            maior = vetor[i];
        } else {
            if(vetor[i] < menor) {
                menor = vetor[i];
            }
            if(vetor[i] > maior) {
                maior = vetor[i];
            }
        }
    }

    media = soma / 30.0;

    printf("\nNumeros pares no vetor:\n");
    for(i = 0; i < 30; i++) {
        if(vetor[i] % 2 == 0) {
            printf("%d ", vetor[i]);
        }
    }

    printf("\n\nMenor valor: %d\n", menor);
    printf("Maior valor: %d\n", maior);

    for(i = 0; i < 30; i++) {
        if(vetor[i] > media) {
            contador_acima_media++;
        }
    }

    printf("Quantidade de valores acima da media (%.2f): %d\n", media, contador_acima_media);

    return 0;
}